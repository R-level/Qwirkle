import za.nmu.mandela.qwirkle_game.Controller.Broker;
import za.nmu.mandela.qwirkle_game.Controller.Client.ClientReceiver;
import za.nmu.mandela.qwirkle_game.Controller.messages.serverMessage.Connected;
import za.nmu.mandela.qwirkle_game.Model.GameState;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
/**Class Main will run a thread and collect any Clients that establish a connection
 * Creating a new ClientReceiver class  */
public class Main {
    GameState gameState;
    Scanner in;
    ClientReceiver clientReceiver;
    public static void main(String[] args) throws IOException {
new Main();
    }
    public Main() throws IOException {
        ServerSocket server = new ServerSocket(5000);
        System.out.printf("Qwirkle server started on: %s:5000\n",
                InetAddress.getLocalHost().getHostAddress());
// Increment number of clients encountered.
        int clientReceiverID = 0;
        while(true) {
            // Accept connection requests.
            Socket client = server.accept();
            System.out.printf("Connection request received: %s\n", client.getInetAddress().getHostAddress());


            clientReceiverID++;

            // Create new client connection object to manage.
        clientReceiver = new ClientReceiver(client,clientReceiverID);
//Store the Client
            Broker.getInstance().getCurrentClientPlayers().add(clientReceiver);
     //     Send the Client Connection message first
            clientReceiver.send(new Connected(clientReceiverID));

        }
    }
}
