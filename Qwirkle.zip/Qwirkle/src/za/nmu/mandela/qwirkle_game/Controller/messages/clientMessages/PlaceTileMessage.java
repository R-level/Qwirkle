package za.nmu.mandela.qwirkle_game.Controller.messages.clientMessages;

import za.nmu.mandela.qwirkle_game.Controller.messages.Message;
import za.nmu.mandela.qwirkle_game.Model.GameState;
import za.nmu.mandela.qwirkle_game.Model.Player.Player;
import za.nmu.mandela.qwirkle_game.Model.Tile.QwirkleTile;

import java.util.List;

public class PlaceTileMessage extends Message {
    private static final long serialVersionUID = 12586812381757438L;
    int playerID;
    int gameStateID;

    List<QwirkleTile> playedTile;
    public PlaceTileMessage(int playerID, int gameStateID, List<QwirkleTile> playedTile){
        this.playerID=playerID;
        this.gameStateID =gameStateID;
        this.playedTile=playedTile;
    }
    public PlaceTileMessage(List<QwirkleTile> qwirkleTiles)
    {this.playedTile = qwirkleTiles;}

    public int getPlayerID() {
        return playerID;
    }

    public int getGameStateID() {
        return gameStateID;
    }

    public List<QwirkleTile> getPlayedTiles() {
        return playedTile;
    }
}
