package za.nmu.mandela.qwirkle_game.Controller.messages.clientMessages;

import za.nmu.mandela.qwirkle_game.Controller.messages.Message;

public class NewGameRequest extends Message {
    private static final long serialVersionUID = 12586812355558L;
    int numPlayers;

    public NewGameRequest(int numPlayers) {
        this.numPlayers = numPlayers;
    }

    public int getNumPlayers() {
        return numPlayers;
    }
}