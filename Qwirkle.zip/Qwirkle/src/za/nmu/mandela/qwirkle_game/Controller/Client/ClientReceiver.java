package za.nmu.mandela.qwirkle_game.Controller.Client;

import za.nmu.mandela.qwirkle_game.Controller.Broker;
import za.nmu.mandela.qwirkle_game.Controller.messages.Message;
import za.nmu.mandela.qwirkle_game.Controller.messages.clientMessages.Quit;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.SQLOutput;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.locks.ReentrantLock;

/**
 * ClientReceiver class must stand as a connection between the client and the server
 * Receives all the messages from a client and routes them to the Broker
 * which updates the gameState of the game that matches the client player
 * gameID
 **/
public class ClientReceiver {
    private int ClientReceiverID;
    private Socket client;

    //IO Streams for communicating with client

    private ObjectInputStream in;

    private ObjectOutputStream out;

    //Thread-safe Queue for sending messages across the network
    private BlockingQueue<Message> outgoingMessages = new LinkedBlockingDeque<>();

    private ReadThread readThread;

    private WriteThread writeThread;

ReentrantLock lock = new ReentrantLock();

    public ClientReceiver(Socket client, int ID) {
        this.client = client;
        this.ClientReceiverID = ID;
        //start read loop thread
       connect( client.getInetAddress().getHostAddress());
    }

    public void connect(String serverAddress) {
        System.out.println("Client: Connecting to " + serverAddress + "...");


        // Start the read thread (which establishes a connection.
        System.out.println("Client: Starting Read Loop thread...");
        readThread = new ReadThread();
        readThread.start();
    }

    public void send(Message message){
        try{
            outgoingMessages.put(message);
        } catch (InterruptedException e) {
            System.out.println(getClientReceiverID() + ": Read.Exception: " + e.getMessage());
        e.printStackTrace();
        }
    }

    private class ReadThread extends Thread {
        @Override
        public void run() {

            try {
                System.out.println("client Receiver number: " + getClientReceiverID() + ": Read thread started.");

                out = new ObjectOutputStream(client.getOutputStream());
                out.flush();
                in = new ObjectInputStream(client.getInputStream());
                System.out.println("client Receiver number: " + getClientReceiverID() + ": Obtained I/O streams. ");
                // Start write loop thread. Start write thread here to ensure
                // that the I/O streams have been initialised correctly BEFORE
                // starting to read and write messages.
                writeThread = new WriteThread();
                writeThread.start();
                System.out.println(getClientReceiverID() + ": Started Read Loop...");
                Message msg;
                do {

                    msg = (Message) in.readObject();
                    System.out.println(getClientReceiverID() + " --> " + msg);
                    //Send the message to the broker
                    Broker.getInstance().messageInbox(msg, getClientReceiverID());

                } while (true);
                //while (msg.getClass() != Quit.class);
                //Close the connection


            } catch (Exception e) {
                System.out.println(getClientReceiverID() + ": Read.Exception: " + e.getMessage());
                e.printStackTrace();
            } finally {
                try {
                    client.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                System.out.println(getClientReceiverID() + ": Leaving Broker...");
                Broker.removeClient(ClientReceiver.this);

                System.out.println(getClientReceiverID() + ": Stopping Write thread...");
                writeThread.interrupt();

                System.out.println(getClientReceiverID() + ": Read thread finished.");
            }

        }
    }

    private class WriteThread extends Thread{
        @Override
        public void run() {
            System.out.println(getClientReceiverID() + ": Started Write Loop thread...");

//Remember this thread
            writeThread = this;

            try{
                //while(isInterrupted()){
                    while(true){
                    lock.lock();
                    if(outgoingMessages.size()>0) {
                        Message msg = outgoingMessages.take();
                        out.writeObject(msg);
                        out.flush();
                        System.out.println(msg + "--> " + getClientReceiverID());
                    }lock.unlock();
                }
            }catch(Exception e){
                System.out.println(getClientReceiverID() + ": Write.Exception = " + e.getMessage());
                e.printStackTrace();
            }finally{
                writeThread = null;
                System.out.println(getClientReceiverID() + ":Write thread finished.");
            }

        }
    }

    public int getClientReceiverID() {
        return ClientReceiverID;
    }

    public void setClientReceiverID(int clientReceiverID) {
        ClientReceiverID = clientReceiverID;
    }
}
