package za.nmu.mandela.qwirkle_game.Controller.messages.serverMessage;

import za.nmu.mandela.qwirkle_game.Controller.messages.Message;

public class NoMoveAllowed extends Message {

}
