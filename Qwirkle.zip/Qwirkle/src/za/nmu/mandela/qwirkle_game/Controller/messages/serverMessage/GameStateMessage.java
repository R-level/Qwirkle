package za.nmu.mandela.qwirkle_game.Controller.messages.serverMessage;

import za.nmu.mandela.qwirkle_game.Controller.messages.Message;
import za.nmu.mandela.qwirkle_game.Model.GameState;
import za.nmu.mandela.qwirkle_game.Model.Tile.QwirkleTile;

import java.io.Serializable;
import java.util.ArrayList;

/**za.nmu.mandela.qwirkle_game_client.Controller.Client.Client.Game message will be sent to all za.nmu.mandela.qwirkle_game_client.Controller.Client.Client players whenever
 * a new state is made.*/
public class GameStateMessage extends Message  {
    private static final long serialVersionUID = 1575314788189816512L;
    ArrayList<QwirkleTile> hand;
    ArrayList<Integer>scores;

    Integer currentPlayerID;
    public GameStateMessage(ArrayList<QwirkleTile> hand,ArrayList<Integer>scores, Integer currentPlayerID){

        this.hand = hand;
        this.scores=scores;
        this.currentPlayerID=currentPlayerID;
    }

    public ArrayList<QwirkleTile> getHand() {
        return hand;
    }

    public ArrayList<Integer> getScores() {
        return scores;
    }

    public Integer getCurrentPlayerID() {
        return currentPlayerID;
    }
}
