package za.nmu.mandela.qwirkle_game.Controller.messages.clientMessages;

import za.nmu.mandela.qwirkle_game.Controller.messages.Message;

public class Quit extends Message {
}
