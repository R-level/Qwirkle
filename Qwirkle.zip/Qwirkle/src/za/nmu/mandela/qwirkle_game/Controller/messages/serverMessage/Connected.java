package za.nmu.mandela.qwirkle_game.Controller.messages.serverMessage;

import za.nmu.mandela.qwirkle_game.Controller.messages.Message;

public class Connected extends Message {
    private static final long serialVersionUID = 102L;
public Integer ID;
    public Connected(int ID) {
    this.ID = ID;
    }

    @Override
    public String toString() {
        return String.format("New Client Connected. Client ID : %s)", ID);
    }
}
