package za.nmu.mandela.qwirkle_game.Controller;

import za.nmu.mandela.qwirkle_game.Controller.Client.ClientReceiver;
import za.nmu.mandela.qwirkle_game.Controller.messages.Message;
import za.nmu.mandela.qwirkle_game.Controller.messages.clientMessages.NewGameRequest;
import za.nmu.mandela.qwirkle_game.Controller.messages.clientMessages.PlaceTileMessage;
import za.nmu.mandela.qwirkle_game.Controller.messages.serverMessage.*;
import za.nmu.mandela.qwirkle_game.Model.GameState;
import za.nmu.mandela.qwirkle_game.Model.Player.Player;
import za.nmu.mandela.qwirkle_game.Model.Tile.QwirkleTile;

import java.util.*;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Broker class orchestrates the messages between the gameState on the server and
 * the individual player Clients playing the Qwirkle game
 * only allowed one instance of Broker accessible through getInstance()
 */
public class Broker {

    /**
     * Storage of all the game instances that
     * will be playing at a given time
     */
    Map<Integer, GameState> currentGames = new HashMap();

    /**
     * A Queue for Clients awaiting to be allocated
     * to a 4 player game
     */
    LinkedList<ClientReceiver> FourPlayerQueue;

    /**
     * A Queue for Clients awaiting to be allocated
     * to a 3 player game
     */
    LinkedList<ClientReceiver> ThreePlayerQueue;

    /**
     * A Queue for Clients awaiting to be allocated
     * to a 2 player game
     */
    LinkedList<ClientReceiver> TwoPlayerQueue;

    List<ClientReceiver> currentClientPlayers = new ArrayList();

    /**
     * GameState counter
     */
    int gameStateCounter = 0;
    // Lock to prevent multiple threads manipulating the groups' data
    // structure while busy with an operation.
    private static final ReentrantLock lock = new ReentrantLock();

    static Broker broker;

    public static Broker getInstance() {
        if (broker == null) {
            broker = new Broker();
        }

        return broker;

    }

    Broker() {
        TwoPlayerQueue = new LinkedList<>();
        ThreePlayerQueue = new LinkedList<>();
        FourPlayerQueue = new LinkedList<>();
    }

    public static void removeClient(ClientReceiver clientReceiver) {
    }

    public void messageInbox(Message message, int clientReceiverID) {
        //Messages will be sent to relevant Action methods
        if (message instanceof NewGameRequest) {
            //Decide which game the client must be in
            NewGameRequest newGameRequest = (NewGameRequest) message;
            int numPlayers = newGameRequest.getNumPlayers();

            ClientReceiver clientReceiver = findClient(clientReceiverID);
            if (clientReceiver != null) {
                if (numPlayers == 2) {
                    getTwoPlayerQueue().addLast(clientReceiver);
                    //ToDO change to 2
                      if (getTwoPlayerQueue().size() >= 2){createGame(2, getTwoPlayerQueue());
                   // if (getTwoPlayerQueue().size() >= 1) {
                   //     createGame(1, getTwoPlayerQueue());
                    }
                }

                if (numPlayers == 3) {
                    getThreePlayerQueue().addLast(clientReceiver);
                    if (getTwoPlayerQueue().size() >= 3) {
                        createGame(3, getTwoPlayerQueue());
                    }
                }

                if (numPlayers == 4) {
                    getFourPlayerQueue().addLast(clientReceiver);
                    if (getTwoPlayerQueue().size() >= 4) {
                        createGame(4, getTwoPlayerQueue());
                    }
                }
            }

        }

        /**PlaceTile Action**/
        if (message instanceof PlaceTileMessage) {
            //Obtain playerID and gameStateID
            PlaceTileMessage placeTileMessage = (PlaceTileMessage) message;
            int playerID = placeTileMessage.getPlayerID();
            //int noPlayers = placeTileMessage.getGameState().getPlayers().size();
            int gameStateID = placeTileMessage.getGameStateID();
            //Find the relevant gameState and call the placeTile method

            GameState gameOfPlaceTileAction = currentGames.get(gameStateID);
            //Check if the currentPlayerID does equal the playerID
            if (gameOfPlaceTileAction.getCurrentPlayer().getID() == playerID) {
                //Obtain the tiles that were played
                List<QwirkleTile> tiles = placeTileMessage.getPlayedTiles();
                for (QwirkleTile tile : tiles) {
                    gameOfPlaceTileAction.placeTile(tile, tile.getxPos(), tile.getyPos());

                    //Publish the place tile on to the gameboard of the other players

                }
                //Get the points for the tile placement
                //Todo Fix points calculations
              //  gameOfPlaceTileAction.getPoints(tiles);
                //Publish the tiles that have been played to other players
                publish(new PlaceTileMessage(tiles), gameOfPlaceTileAction.getPlayers());

                //Change the turn in the game
                gameOfPlaceTileAction.changeTurn();
                //Get the array of scores
                ArrayList<Integer> scores =gameOfPlaceTileAction.getScores();
                //Get the player ID of the current player
                Integer currentPlayerID = gameOfPlaceTileAction.getCurrentPlayer().getID();
                //Send game state to all clients in the shared game
                for(Player player:gameOfPlaceTileAction.getPlayers()) {
                    ClientReceiver client = findClient(player.getClientReceiverID());
                  ArrayList<QwirkleTile> playerHand = player.getHand();
for(int i=0;i<playerHand.size();i++){
    client.send(new UpdatePlayerHand(playerHand.get(i),i));
}
                    client.send(new UpdateGame(playerHand,scores ,currentPlayerID));
                }
            } else {
                /**Not your turn yet*/
                send(new InvalidMove(), clientReceiverID);
            }
            //if false is obtained send a message back to the Client informing them of the
            // Not your turn
        }
        //Client has started a new game, send the tiles to the player hand.


    }

    /**
     * Create a game on the server and send NewGameStart Message to all Players
     **/
    private void createGame(int numPlayer, LinkedList<ClientReceiver> PlayerQueue) {
        //Create new GameState

        gameStateCounter++;
        GameState gameState = new GameState(numPlayer, gameStateCounter);
        List<Player> players = new ArrayList<>();
        for (int i = 1; i <= numPlayer; i++) {
            ClientReceiver clientReceiver = PlayerQueue.removeFirst();
            int clientReceiverID = clientReceiver.getClientReceiverID();

            Player player = new Player(gameState, i, clientReceiverID);
            players.add(i - 1, player);
        }
        //Set the players and deal their hands
        gameState.setPlayers(players);

        //Store the game
        currentGames.put(gameState.getGameStateID(), gameState);
        //send each Player a GameStartMessage
        for (Player p : players) {
            ClientReceiver client = findClient(p.getClientReceiverID());
            client.send(new NewGameStart(gameState, p.getID(), p.getHand(),gameState.getCurrentPlayer().getID()));

        }

    }

    ClientReceiver findClient(int clientReceiverID) {
        for (ClientReceiver clientReceiver : currentClientPlayers) {
            if (clientReceiver.getClientReceiverID() == clientReceiverID) {
                return clientReceiver;
            }
        }
        return null;
    }

    public void publish(Message message, List<Player> players) {

        for (Player player : players) {
            send(message, player.getClientReceiverID());
        }

    }


    public void send(Message msg, int clientReceiverID) {
        lock.lock();
        for (ClientReceiver client : currentClientPlayers) {
            if (client.getClientReceiverID() == clientReceiverID) {
                client.send(msg);
                break;
            }
        }
        lock.unlock();
    }

    public List<ClientReceiver> getCurrentClientPlayers() {
        return currentClientPlayers;
    }


    /**
     * Get the List for the client receiver
     */
    public LinkedList<ClientReceiver> getFourPlayerQueue() {
        return FourPlayerQueue;
    }

    public LinkedList<ClientReceiver> getThreePlayerQueue() {
        return ThreePlayerQueue;
    }

    public LinkedList<ClientReceiver> getTwoPlayerQueue() {
        return TwoPlayerQueue;
    }
}
