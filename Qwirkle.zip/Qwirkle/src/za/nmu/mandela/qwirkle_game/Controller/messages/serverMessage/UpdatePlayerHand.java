package za.nmu.mandela.qwirkle_game.Controller.messages.serverMessage;

import za.nmu.mandela.qwirkle_game.Controller.messages.Message;
import za.nmu.mandela.qwirkle_game.Model.Tile.QwirkleTile;

import java.util.ArrayList;

public class UpdatePlayerHand extends Message {
    private static final long serialVersionUID = 11122572L;

    QwirkleTile hand;
    Integer posHand;
    public UpdatePlayerHand(QwirkleTile hand, Integer posHand) {


        this.hand = hand;
        this.posHand=posHand;
    }

    public QwirkleTile getHand() {
        return hand;
    }

    public Integer getPosHand() {
        return posHand;
    }
}
