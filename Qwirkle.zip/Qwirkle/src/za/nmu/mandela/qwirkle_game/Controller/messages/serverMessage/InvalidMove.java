package za.nmu.mandela.qwirkle_game.Controller.messages.serverMessage;

import za.nmu.mandela.qwirkle_game.Controller.messages.Message;

public class InvalidMove extends Message {
    private static final long serialVersionUID = 103L;

    public InvalidMove() {
    }

}
