package za.nmu.mandela.qwirkle_game.Controller.messages;

import java.io.Serializable;

/**Messages will inherit from this Message class**/
public abstract class Message implements Serializable {
   private static final long serialVersionUID = 999L;
   public void apply(){}
}
