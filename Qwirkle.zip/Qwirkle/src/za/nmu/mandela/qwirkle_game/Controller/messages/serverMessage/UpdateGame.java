package za.nmu.mandela.qwirkle_game.Controller.messages.serverMessage;

import java.util.ArrayList;

import za.nmu.mandela.qwirkle_game.Controller.messages.Message;
import za.nmu.mandela.qwirkle_game.Model.Tile.QwirkleTile;

public class UpdateGame extends Message {

    private static final long serialVersionUID = 11111102L;


    ArrayList<Integer> scores;

    Integer currentPlayerID;
    public UpdateGame(ArrayList<QwirkleTile> hand, ArrayList<Integer> scores, Integer currentPlayerID) {



        this.scores = scores;
        this.currentPlayerID = currentPlayerID;
}



    public ArrayList<Integer> getScores() {
        return scores;
    }

    public Integer getCurrentPlayerID() {
        return currentPlayerID;
    }
}


