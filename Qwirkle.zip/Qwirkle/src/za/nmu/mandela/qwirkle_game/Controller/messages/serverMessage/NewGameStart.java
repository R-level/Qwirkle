package za.nmu.mandela.qwirkle_game.Controller.messages.serverMessage;

import za.nmu.mandela.qwirkle_game.Controller.messages.Message;
import za.nmu.mandela.qwirkle_game.Model.GameState;
import za.nmu.mandela.qwirkle_game.Model.Tile.QwirkleTile;

import java.io.Serializable;
import java.util.ArrayList;

public class NewGameStart extends Message implements Serializable {
    private static final long serialVersionUID = 188L;
    public GameState gameState;
    public int clientPlayerID;
    ArrayList<QwirkleTile> hand;
    Integer currentPlayerID;

    public NewGameStart(GameState gameState, int clientPlayerID, ArrayList<QwirkleTile> hand, Integer currentPlayerID) {
        this.gameState = gameState;
        this.clientPlayerID = clientPlayerID;
        this.hand = hand;
        this.currentPlayerID = currentPlayerID;
    }

    public ArrayList<QwirkleTile> getHand() {
        return hand;
    }

    public GameState getGameState() {
        return gameState;
    }

    public int getClientPlayerID() {
        return clientPlayerID;
    }

    public Integer getCurrentPlayerID() {
        return currentPlayerID;
    }
}
