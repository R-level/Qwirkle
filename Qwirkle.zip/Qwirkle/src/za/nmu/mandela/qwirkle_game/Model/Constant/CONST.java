package za.nmu.mandela.qwirkle_game.Model.Constant;

public class CONST {
  public static int  BOARD_WIDTH = 30;
  public static int BOARD_HEIGHT = 30;

  public CONST(){}
}
