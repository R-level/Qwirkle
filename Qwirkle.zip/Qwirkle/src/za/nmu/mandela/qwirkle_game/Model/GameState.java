package za.nmu.mandela.qwirkle_game.Model;

import za.nmu.mandela.qwirkle_game.Controller.messages.Message;
import za.nmu.mandela.qwirkle_game.Model.GameBoard;
import za.nmu.mandela.qwirkle_game.Model.Player.Player;
import za.nmu.mandela.qwirkle_game.Model.Rules.QwirkleRules;
import za.nmu.mandela.qwirkle_game.Model.Tile.QwirkleColour;
import za.nmu.mandela.qwirkle_game.Model.Tile.QwirkleShape;
import za.nmu.mandela.qwirkle_game.Model.Tile.QwirkleTile;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * The game state class will contain all information for the game
 **/
public class GameState extends Message implements Serializable {

    private static final long serialVersionUID = 300L;
    QwirkleRules rules;
    GameBoard gameBoard;
    Player currentPlayer;
    int noPlayers;

    ArrayList<QwirkleTile> tileBag = new ArrayList<>();
    List<Player> players;

    int gameStateID;
    boolean gameOver;

    //Random Class variable for allocating random tiles to players
    Random random = new Random();

    public GameState(int numPlayers, int ID) {
        this.noPlayers = numPlayers;
        gameBoard = new GameBoard();
        rules = new QwirkleRules();
        gameOver = false;
        players = new ArrayList<>();
        gameStateID = ID;
        init();
    }

    /**
     * Create a copy of the current GameState to send to the clients
     * exclude the list of players to avoid peaking into player hand
     */
    public GameState() {


    }
    public ArrayList<Integer> getScores(){
        ArrayList<Integer> scores = new ArrayList<>();
        for(Player player:players){
            scores.add(player.getScore());
        }
        return scores;
    }

    //todo Need to keep the game going and changing players while game is not over.
    //Add the players to the game
    public void init() {

        //Initialize the tile bag for the game
        for (QwirkleColour colour : QwirkleColour.values()) {
            for (QwirkleShape shape : QwirkleShape.values()) {
                //Add this tile 3 times to the bag
                for (int i = 0; i < 3; i++) {
                    tileBag.add(new QwirkleTile(shape, colour));
                }
            }
        }



    }

    /**
     * GameState ID will be used to identify which game a player is in
     */
    public int getGameStateID() {
        return gameStateID;
    }

    /**
     * Method to set the game ID
     **/
    public void setGameStateID(int gameStateID) {
        this.gameStateID = gameStateID;
    }

    /**
     * Change the turn of the player
     */
    public void changeTurn() {
        int currentIndex = players.indexOf(currentPlayer);
        if ((currentIndex + 1) == players.size()) {
            //If last player then move to first player again
            setCurrentPlayer(players.get(0));
        } else {
            //If not last player move to next player
            setCurrentPlayer(players.get(currentIndex + 1));
        }
    }

    /**
     * Get the list of players in the current gameState
     **/
    public List<Player> getPlayers() {
        return players;
    }

    /**
     * Set the list of players in the current gameState
     **/
    public void setPlayers(List<Player> players) {
        this.players = players;
        for (int i = 0; i < noPlayers; i++) {


            for (int j = 0; j < 6; j++) {//remove a random tile from the tile bag and add to the hand of the current player
                players.get(i).getHand().add(tileBag.remove(random.nextInt(0, tileBag.size())));
            }
        }
        setCurrentPlayer(players.get(0));
    }

    /**
     * The current player is set
     */
    public void setCurrentPlayer(Player player) {
        currentPlayer = player;
    }

    /**
     * Get the current za.nmu.mandela.qwirkle_game_client.Model.Player.Player
     */
    public Player getCurrentPlayer() {
        return currentPlayer;
    }

    /**
     * Get the rules of the Qwirkle game
     */
    public QwirkleRules getRules() {
        return rules;
    }

    /**
     * getGameBoard will return the game board
     **/
    public GameBoard getGameBoard() {
        return gameBoard;
    }


    /**
     * Place the tile in the gameboard
     */
    public void placeTile(QwirkleTile tileToBePlaced, int x, int y) {
        gameBoard.placeTile(tileToBePlaced, x, y);
        players.get(getCurrentPlayer().getID()-1).remove(tileToBePlaced);
        if(!tileBag.isEmpty())
        { //remove a tile from the bag and add it to the currentPlayer's hand
            players.get(getCurrentPlayer().getID()-1).getHand().add(tileBag.remove(random.nextInt(0,tileBag.size())));}
    }

    /**
     * getPoints is called when player Accepts the tiles being placed
     */
    public void getPoints(List<QwirkleTile> playedTiles) {
        ArrayList tiles=(ArrayList) playedTiles;
        int points = rules.getPoints(tiles);
//update the scoreboard
        getCurrentPlayer().setScore(points);
    }



    /**
     * Game Over status
     */
    public boolean isGameOver() {
        return gameOver;
    }

    /**
     * Set Game Over status
     */
    public void setGameOver(boolean gameOver) {
        this.gameOver = gameOver;
    }

    public GameState getThis() {
        return this;
    }
}
