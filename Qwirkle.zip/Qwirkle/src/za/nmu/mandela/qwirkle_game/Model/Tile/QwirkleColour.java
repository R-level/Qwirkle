package za.nmu.mandela.qwirkle_game.Model.Tile;

import java.io.Serializable;

public enum QwirkleColour implements Serializable {
    red,yellow,green,purple,blue,orange;
}
